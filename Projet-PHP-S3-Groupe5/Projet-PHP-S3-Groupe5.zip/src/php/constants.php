<?php
define ("DB_USER", '');
define ("DB_PASSWORD", '');
define ("DB_NAME", '');
define ("DB_SERVER", '');
define ("DB_PORT", '');
?>