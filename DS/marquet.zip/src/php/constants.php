<?php
define ("DB_USER", 'postgres');
define ("DB_PASSWORD", 'a');
define ("DB_NAME", 'solde');
define ("DB_SERVER", '172.29.205.116');
define ("DB_PORT", '5432');
?>